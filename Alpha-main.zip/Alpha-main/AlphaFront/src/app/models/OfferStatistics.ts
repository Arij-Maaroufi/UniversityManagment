export class OfferStatistics{
    offerId!:number;
    company!:string;
    description!:string;
    applicationCount!:number;
}