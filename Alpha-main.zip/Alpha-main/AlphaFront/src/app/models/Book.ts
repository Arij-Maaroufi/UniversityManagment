export class Book{
    
    id: number | undefined;

    title!: string;

    auteur!:string;

    date!:Date;

    type!:string;

    description!:string;

    cover!:string;
    file!:string;
}