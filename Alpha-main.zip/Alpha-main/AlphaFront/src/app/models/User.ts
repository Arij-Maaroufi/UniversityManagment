export class User{
  
    id!: number;
    name!: string
    email!: string
    password!: string
    phone!: number
    adress!: string
    role!: string
    studentClass!: string
      
}