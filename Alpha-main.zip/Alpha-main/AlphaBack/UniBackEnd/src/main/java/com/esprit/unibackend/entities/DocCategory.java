package com.esprit.unibackend.entities;

public enum DocCategory {
    ressource,post
}
