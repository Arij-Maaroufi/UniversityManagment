package com.esprit.unibackend.entities;

public enum typeOffre {
    Formation, Stage, Emploi
}
