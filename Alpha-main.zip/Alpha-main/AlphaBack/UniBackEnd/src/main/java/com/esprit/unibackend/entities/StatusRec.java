package com.esprit.unibackend.entities;

public enum StatusRec {
    EnAttente,Valide,Refuse
}
