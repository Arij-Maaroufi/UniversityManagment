package com.esprit.unibackend.payload.request;

public class SignatureRequest {

    private String signatureData;

    public String getSignatureData() {
        return signatureData;
    }

    public void setSignatureData(String signatureData) {
        this.signatureData = signatureData;
    }
}
